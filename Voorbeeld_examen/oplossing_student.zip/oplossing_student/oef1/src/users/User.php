<?php namespace users;
//naam: Maarten Warson

use identifiable\Identifiable;

abstract class User extends Identifiable {

}